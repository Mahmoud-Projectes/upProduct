<?php

include __DIR__ . '/../printStr.php';