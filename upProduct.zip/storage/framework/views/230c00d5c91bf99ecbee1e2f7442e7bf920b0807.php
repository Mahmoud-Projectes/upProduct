<?php $__env->startSection('main_navbar'); ?>
    <?php echo $__env->make('layouts.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>









<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <form id="search-form" method="POST" action="<?php echo e(route('search')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-row col-12">
                        <div class="col-10">
                            <input id="input-search" class="form-control" value="<?php echo e($old??''); ?>" type="text" name="search" placeholder="البحث عن الموظف إما برقم التوظيف أو الاسم." required>
                        </div>
                        <div class="col-2">
                            <input class="btn btn-primary btn-block" value="ابحث" type="submit">
                        </div>
                    </div>
                </form>

                <?php if($errors->has('search')): ?>
                <div class="col-12 text-right text-danger font-weight-bolder small">
                    <span>
                        <?php echo e($errors->first('search')); ?>

                    </span>
                </div>
                <?php endif; ?>








                <?php if(isset($message)): ?>
                    <div class="col-12 text-right mt-3 pl-4">
                        <div class="alert alert-<?php echo e(($state)?'success':'info'); ?> small">
                            <img src="<?php echo e(asset('images/icons/' . ($state? 'update-icon.svg':'add.svg'))); ?>" class="app-filter-<?php echo e(($state? 'green':'blue')); ?>" width="16px" >
                            <span class="mr-1">
                            <?php echo e($message); ?>

                            </span>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if(isset($data)): ?>
                    <?php if($data->count() === 1): ?>
                    <form method="POST" action="<?php echo e(route('store')); ?>">
                        <div class="col-12 pl-4 mt-4">
                            <div class="card">
                                <div class="card-header app-card-table">
                                    <table class="table table-borderless text-center m-0">
                                        <thead>
                                            <tr>
                                                <td width="10%">رقم الموظف</td>
                                                <td width="30%">اسم الموظف</td>
                                                <td width="40%">الإنتاج الحالي</td>
                                            </tr>
                                        </thead>
                                    </table>
                                </div>
                                <div class="card-body app-card-table">
                                    <table class="table table-borderless text-center m-0">
                                        <thead>
                                        <tr>
                                            <td width="10%"><?php echo e($data->first()['id_emp']); ?></td>
                                            <td width="30%"><?php echo e($data->first()['name']); ?></td>
                                            <td width="40%" class="text-right">
                                                <input type="text" class="form-control" name="id_emp" value="<?php echo e($data->first()['id_emp']); ?>" hidden>
                                                <input type="text" class="form-control" name="name" value="<?php echo e($data->first()['name']); ?>" hidden>
                                                <input type="text" class="form-control" name="production">
                                                <?php if($errors->has('production')): ?>
                                                <small class="small text-danger"><?php echo e($errors->first('production')); ?></small>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                        </thead>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-2 col-lg-3 col-md-4 col-sm-12">
                            <?php echo csrf_field(); ?>
                            <input type="submit" class="btn btn-primary btn-block mt-4" value="تحديث">
                        </div>
                    </form>
                    <?php else: ?>
                        <div class="col-12 pt-3 pl-4 text-right">
                            <div class="list-group">
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a  class="list-group-item list-group-item-action"
                                        onclick="getForm(<?php echo e($item['id_emp']); ?>);">
                                        <span class="badge-info badge-pill small"><strong><?php echo e($item['id_emp']); ?></strong></span>
                                        <span class="mr-4"><?php echo e($item['name']); ?></span>
                                    </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php else: ?>
                    <div class="col-12 text-center mt-5">
                        <span class="text-muted"><?php echo e($messageStart); ?></span>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main_footer'); ?>
    <?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appmain', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>