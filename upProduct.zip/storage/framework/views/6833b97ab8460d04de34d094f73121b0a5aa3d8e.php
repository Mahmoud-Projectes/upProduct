<?php $__env->startSection('navbar'); ?>
<nav class="navbar navbar-expand-md navbar-dark bg-dark">
    <?php echo $__env->yieldContent('main_navbar'); ?>
</nav>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<footer class="text-center text-lg-start app-footer">
    <?php echo $__env->yieldContent('main_footer'); ?>
</footer>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>