<!-- Copyright -->
<div class="text-center p-3" dir="ltr" style="background-color: rgba(0, 0, 0, 0.2)">
    © 2021 Copyright:
    <a class="text-dark" href="https://almatin.com/">almatin.com</a>
    <p class="text-dark small m-0 font-weight-normal">تطوير وبرمجة: م.محمود ممدوح باكير</p>
</div>
<!-- Copyright -->