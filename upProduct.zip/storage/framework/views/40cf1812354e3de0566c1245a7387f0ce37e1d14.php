<a class="navbar-brand" href="<?php echo e(url('/')); ?>">Almatin Company</a>
<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
</button>
<div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav font-weight-lighter">
        <li class="nav-item <?php echo e($navHome??''); ?>">
            <a class="nav-link" href="<?php echo e(route('index')); ?>">الصفحة الرئيسية <span class="sr-only">(current)</span></a>
        </li>
        <li class="nav-item <?php echo e($navProduction??''); ?>">
            <a class="nav-link" href="<?php echo e(route('production.index')); ?>">إدخال الإنتاج</a>
        </li>
        <li class="nav-item <?php echo e($navStatistics??''); ?>">
            <a class="nav-link" href="<?php echo e(route('statistics')); ?>">إحصائيات</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('logout')); ?>"
            onclick="event.preventDefault();
                     document.getElementById('logout-form').submit();">تسجيل الخروج</a>
        </li>
        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
            <?php echo csrf_field(); ?>
        </form>
    </ul>
</div>