<?php $__env->startSection('main_navbar'); ?>
    <p>navbar</p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header"></div>
                        welcome to project.
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main_footer'); ?>
    <p>footer</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appmain', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>