<?php $__env->startSection('main_navbar'); ?>
    <?php echo $__env->make('layouts.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="form-row justify-content-start text-right">
            <div class="col-12 ">
                <span>أهلا بك <span style="color:red"><?php echo e($userProd['name']??''); ?></span>  في برنامج تحديث انتاج الموظفين.</span>
                <table class="table table-responsive-xl mt-3">
                    <tr>
                        <td class="app-tb-td">رقمك الوظيفي:</td>
                        <td><span class="badge-pill badge-primary"><?php echo e($userProd['numberid']??''); ?></span></td>
                    </tr>
                    <tr>
                        <td>عدد موظفين الإنتاج:</td>
                        <td><?php echo e($count??'0'); ?> موظف</td>
                    </tr>
                </table>
            </div>
            <div class="col-xl-2 col-lg-2 col-md-3 col-sm-12 app-btn-mb">
                <a class="btn btn-primary btn-block" href="<?php echo e(route('production.index')); ?>">إدخال الإنتاج</a>
            </div>
            <div class="col-xl-2 col-lg-2 col-md-3 col-sm-12">
                <a class="btn btn-primary btn-block" href="<?php echo e(route('statistics')); ?>">احصائيات</a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main_footer'); ?>
    <?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appmain', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>