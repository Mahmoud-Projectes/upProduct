<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Almatin login')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
</head>
<body>
    <div id="main" class="app-container-main">
        <?php echo $__env->yieldContent('navbar'); ?>
        <main class="app-content-main">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
        <?php echo $__env->yieldContent('footer'); ?>
    </div>
<script>
function getForm(value) {
    document.getElementById('input-search').value = value;
    event.preventDefault();
    document.getElementById('search-form').submit()
}
</script>
</body>
</html>