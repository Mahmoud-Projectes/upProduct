<?php $__env->startSection('main_navbar'); ?>
    <?php echo $__env->make('layouts.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="form-row justify-content-start text-right">
            <?php if($isProduct): ?>
            <div class="col-12 mb-3">
                <span>يظهر هذ الجدول الموظفين التي تم إضافتهم اليوم:</span>
                <table class="table table-responsive-sm mt-3">
                    <thead>
                        <td>الرقم الوظيفي</td>
                        <td>الاسم</td>
                        <td>الانتاج اليومي</td>
                        <td>الانتاج الكلي خلال الشهر</td>
                        <td>تاريخ الإضافة</td>
                    </thead>
                    <?php $__currentLoopData = $prodEmployees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><span class="badge-primary badge-pill"><?php echo e($emps['id_emp']); ?></span></td>
                        <td><?php echo e($emps['name']); ?></td>
                        <td><span class="badge-dark badge-pill"><?php echo e($emps['production']); ?></span></td>
                        <td><span class="badge-dark badge-pill"><?php echo e($emps['all_production']); ?></span></td>
                        <td><span class="badge-dark badge-pill pl-0">
                                <?php echo e(\Illuminate\Support\Carbon::createFromTimeString($emps['updated_at'])->toDateString()); ?>

                                <span class="badge-primary badge-pill">
                                    <?php echo e(\Illuminate\Support\Carbon::createFromTimeString($emps['updated_at'])->toTimeString()); ?>

                                </span>
                            </span></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
            <?php else: ?>
                <div class="col-12 mb-4 border p-5">
                    <div class="text-muted text-center">لايوجد أي إدخال في هذا الشهر بتاريخ: <?php echo e(date("Y-m-d")); ?></div>
                </div>
            <?php endif; ?>
        <div class="col-12">
            <?php if(session()->has('error')): ?>
                <div class="alert alert-danger alert-dismissible small">
                    <div><?php echo e(session()->get('error')); ?></div>
                    <button type="button" class="close" data-dismiss="alert">×</button>
                </div>
            <?php endif; ?>
        </div>
        <div class="col-xl-3 col-lg-3 col-md-4 col-sm-12 app-btn-mb">
            <a class="btn btn-info btn-block" href="<?php echo e(route('statistics.downloadFileDay')); ?>"><img src="<?php echo e(asset('images/icons/pdf-icon.svg')); ?>" width="16px"/><span class="pr-1">تحميل ملف الإنتاج اليومي</span></a>
        </div>
        <div class="col-xl-3 col-lg-4 col-md-4 col-sm-12 app-btn-mb">
            <a class="btn btn-info btn-block" href="<?php echo e(route('statistics.downloadFileMonth')); ?>"><img src="<?php echo e(asset('images/icons/pdf-icon.svg')); ?>" width="16px"/><span class="pr-1">تحميل ملف أخر انتاج  في هذا الشهر</span></a>
        </div>
        <div class="col-xl-2 col-lg-2 col-md-2 col-sm-12 app-btn-mb">
            <a class="btn btn-info btn-block" data-toggle="collapse" data-target="#lastmonth"><img src="<?php echo e(asset('images/icons/pdf-icon.svg')); ?>" width="16px"/><span class="pr-1">الأشهر الماضية</span></a>
        </div>
        <div class="col-xl-2 col-lg-2 col-md-2 col-sm-12">
            <a class="btn btn-primary btn-block" href="<?php echo e(route('index')); ?>">عودة</a>
        </div>
    </div>
        <div class="collapse" id="lastmonth">
            <div class="col-12 border p-4 mt-3" >
                <?php if($listFile->count() > 0): ?>
                    <form method="post" action="<?php echo e(route('statistics.downloadLastFile')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-row">
                            <div class="col-10">
                                <select class="form-control" name="datefile">
                                    <?php for($i = 0; $i < $listFile->count(); ++$i): ?>
                                        <option selected><?php echo e($listFile->first()['date']); ?></option>
                                    <?php endfor; ?>
                                </select>
                            </div>
                            <div class="col-2">
                                <button class="btn btn-info btn-block" type="submit"><img src="<?php echo e(asset('images/icons/pdf-icon.svg')); ?>" width="16px"/><span class="pr-1">تحميل الملف</span></button>
                            </div>
                        </div>
                    </form>
                <?php else: ?>
                    <div class="text-muted text-center">لايوجد ملفات شهرية حاليا.</div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main_footer'); ?>
    <?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appmain', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>